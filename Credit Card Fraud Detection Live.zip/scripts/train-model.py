import numpy as np
import pandas as pd
import json
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, matthews_corrcoef, confusion_matrix

# Load your creditcard.csv from the URL or local path
# For this example, we'll use the sample data structure
try:
    df = pd.read_csv("/content/creditcard.csv")
except:
    print("Error: Could not load creditcard.csv")
    print("Please ensure the file is available at /content/creditcard.csv")
    exit(1)

# Summary statistics
print("Dataset shape:", df.shape)
print("\nSummary statistics:")
print(df.describe())

# Separate fraudulent and valid transactions
fraud = df[df['Class'] == 1]
valid = df[df['Class'] == 0]
outlierFraction = len(fraud)/float(len(valid))

print(f"\nFraud Cases: {len(df[df['Class'] == 1])}")
print(f"Valid Transactions: {len(df[df['Class'] == 0])}")
print(f"Outlier Fraction: {outlierFraction}")

# Amount details
print("\nAmount details of fraudulent transactions:")
print(fraud.Amount.describe())
print("\nAmount details of valid transactions:")
print(valid.Amount.describe())

# Remove missing values
df = df.dropna(subset=["Class"])

# Prepare features and target
X = df.drop(['Class'], axis=1)
Y = df["Class"]

print(f"\nFeatures shape: {X.shape}")
print(f"Target shape: {Y.shape}")

# Split data
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

# Train Random Forest Classifier
print("\nTraining Random Forest Classifier...")
rfc = RandomForestClassifier(random_state=42, n_estimators=100)
rfc.fit(x_train, y_train)

# Make predictions
y_pred = rfc.predict(x_test)

# Evaluate model
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
mcc = matthews_corrcoef(y_test, y_pred)

print("\nModel Evaluation Metrics:")
print(f"Accuracy: {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1-Score: {f1:.4f}")
print(f"Matthews Correlation Coefficient: {mcc:.4f}")

# Confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)
print("\nConfusion Matrix:")
print(conf_matrix)

# Feature importance
feature_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': rfc.feature_importances_
}).sort_values('importance', ascending=False)

print("\nTop 10 Feature Importance:")
print(feature_importance.head(10))

# Prepare results for JSON output
results = {
    "metrics": {
        "accuracy": round(accuracy, 4),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1_score": round(f1, 4),
        "mcc": round(mcc, 4),
    },
    "dataset": {
        "fraud_cases": int(len(fraud)),
        "valid_transactions": int(len(valid)),
        "total_transactions": int(len(df)),
        "fraud_percentage": round((len(fraud) / len(df)) * 100, 2),
    },
    "amounts": {
        "fraud_amount": round(float(fraud.Amount.sum()), 2),
        "valid_amount": round(float(valid.Amount.sum()), 2),
    },
    "confusion_matrix": {
        "true_negatives": int(conf_matrix[0, 0]),
        "false_positives": int(conf_matrix[0, 1]),
        "false_negatives": int(conf_matrix[1, 0]),
        "true_positives": int(conf_matrix[1, 1]),
    },
    "feature_importance": feature_importance.head(8).to_dict('records'),
}

# Save results to JSON
with open('model_results.json', 'w') as f:
    json.dump(results, f, indent=2)

print("\nResults saved to model_results.json")
