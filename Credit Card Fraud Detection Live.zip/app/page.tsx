"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from "recharts"
import { TrendingUp, AlertTriangle, CheckCircle, Database, Loader } from "lucide-react"
import { FraudDetectorForm } from "@/components/fraud-detector-form"

interface ModelMetrics {
  metrics: {
    accuracy: number
    precision: number
    recall: number
    f1_score: number
    mcc: number
  }
  dataset: {
    fraud_cases: number
    valid_transactions: number
    total_transactions: number
    fraud_percentage: number
  }
  amounts: {
    fraud_amount: number
    valid_amount: number
  }
  confusion_matrix: {
    true_negatives: number
    false_positives: number
    false_negatives: number
    true_positives: number
  }
  feature_importance: Array<{ feature: string; importance: number }>
}

export default function Page() {
  const [data, setData] = useState<ModelMetrics | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const response = await fetch("/api/model-metrics")
        if (!response.ok) throw new Error("Failed to fetch metrics")
        const metrics = await response.json()
        setData(metrics)
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unknown error")
      } finally {
        setLoading(false)
      }
    }

    fetchMetrics()
  }, [])

  if (loading) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader className="w-8 h-8 text-blue-500 animate-spin" />
          <p className="text-slate-300">Loading model metrics...</p>
        </div>
      </main>
    )
  }

  if (error || !data) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8 flex items-center justify-center">
        <Card className="bg-red-900/20 border-red-700">
          <CardContent className="pt-6">
            <p className="text-red-400">Error: {error || "Failed to load data"}</p>
          </CardContent>
        </Card>
      </main>
    )
  }

  const confusionMatrix = [
    { label: "True Negatives", value: data.confusion_matrix.true_negatives, color: "#22c55e" },
    { label: "False Positives", value: data.confusion_matrix.false_positives, color: "#ef4444" },
    { label: "False Negatives", value: data.confusion_matrix.false_negatives, color: "#f97316" },
    { label: "True Positives", value: data.confusion_matrix.true_positives, color: "#3b82f6" },
  ]

  const transactionData = [
    { name: "Valid", value: data.dataset.valid_transactions, percentage: 99.83 },
    { name: "Fraud", value: data.dataset.fraud_cases, percentage: 0.17 },
  ]

  const amountData = [
    { name: "Valid", value: data.amounts.valid_amount, percentage: 95.12 },
    { name: "Fraud", value: data.amounts.fraud_amount, percentage: 4.88 },
  ]

  const COLORS_FRAUD = ["#22c55e", "#ef4444"]

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-white flex items-center gap-3">
            <AlertTriangle className="w-8 h-8 text-blue-500" />
            Fraud Detection Model Analytics
          </h1>
          <p className="text-slate-400">Random Forest Classifier • 20% Test Split • 284,807 Total Transactions</p>
        </div>

        {/* Fraud Detection Form */}
        <FraudDetectorForm />

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-300">Accuracy</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-400">{(data.metrics.accuracy * 100).toFixed(2)}%</div>
              <p className="text-xs text-slate-500 mt-1">Overall correctness</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-300">Precision</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-400">{(data.metrics.precision * 100).toFixed(2)}%</div>
              <p className="text-xs text-slate-500 mt-1">True fraud detected</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-300">Recall</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-400">{(data.metrics.recall * 100).toFixed(2)}%</div>
              <p className="text-xs text-slate-500 mt-1">Caught fraud cases</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-300">F1-Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-violet-400">{(data.metrics.f1_score * 100).toFixed(2)}%</div>
              <p className="text-xs text-slate-500 mt-1">Harmonic mean</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-300">MCC</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-pink-400">{(data.metrics.mcc * 100).toFixed(2)}%</div>
              <p className="text-xs text-slate-500 mt-1">Quality of prediction</p>
            </CardContent>
          </Card>
        </div>

        {/* Transaction Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Transaction Count */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5 text-blue-500" />
                Transaction Distribution
              </CardTitle>
              <CardDescription>Total transactions in dataset</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={transactionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percentage }) => `${name}: ${percentage}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {transactionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS_FRAUD[index % COLORS_FRAUD.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => value.toLocaleString()} />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Valid Transactions:</span>
                  <span className="font-semibold text-green-400">
                    {data.dataset.valid_transactions.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Fraudulent Cases:</span>
                  <span className="font-semibold text-red-400">{data.dataset.fraud_cases.toLocaleString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Amount Distribution */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-500" />
                Transaction Amount Distribution
              </CardTitle>
              <CardDescription>Total value by transaction type</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={amountData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percentage }) => `${name}: ${percentage.toFixed(1)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {amountData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS_FRAUD[index % COLORS_FRAUD.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `$${value.toFixed(2)}`} />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Valid Amount:</span>
                  <span className="font-semibold text-green-400">
                    ${data.amounts.valid_amount.toLocaleString("en-US", { maximumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Fraud Amount:</span>
                  <span className="font-semibold text-red-400">
                    ${data.amounts.fraud_amount.toLocaleString("en-US", { maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Confusion Matrix */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-blue-500" />
              Confusion Matrix
            </CardTitle>
            <CardDescription>Model prediction accuracy breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={confusionMatrix} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis type="number" stroke="#94a3b8" />
                <YAxis dataKey="label" type="category" stroke="#94a3b8" width={120} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1e293b",
                    border: "1px solid #475569",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="value" fill="#3b82f6" radius={[0, 8, 8, 0]}>
                  {confusionMatrix.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-3">
              {confusionMatrix.map((item, index) => (
                <div key={index} className="bg-slate-700/50 rounded-lg p-3">
                  <div className="text-xs text-slate-400 mb-1">{item.label}</div>
                  <div className="text-xl font-bold" style={{ color: item.color }}>
                    {item.value.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Feature Importance */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              Feature Importance
            </CardTitle>
            <CardDescription>Top features influencing fraud detection</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart
                data={data.feature_importance.map((f) => ({
                  feature: f.feature,
                  importance: f.importance,
                }))}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="feature" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1e293b",
                    border: "1px solid #475569",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="importance" fill="#3b82f6" radius={[8, 8, 0, 0]}>
                  {data.feature_importance.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.importance > 0.1 ? "#ef4444" : "#3b82f6"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Model Summary */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle>Model Summary</CardTitle>
            <CardDescription>Random Forest Classifier Performance</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="font-semibold text-slate-200">Dataset Overview</h3>
                <div className="space-y-2 text-sm text-slate-400">
                  <div>
                    Total Transactions:{" "}
                    <span className="text-slate-200 font-semibold">
                      {data.dataset.total_transactions.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    Fraud Cases:{" "}
                    <span className="text-red-400 font-semibold">
                      {data.dataset.fraud_cases.toLocaleString()} ({data.dataset.fraud_percentage}%)
                    </span>
                  </div>
                  <div>
                    Valid Cases:{" "}
                    <span className="text-green-400 font-semibold">
                      {data.dataset.valid_transactions.toLocaleString()} (
                      {(100 - data.dataset.fraud_percentage).toFixed(2)}%)
                    </span>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <h3 className="font-semibold text-slate-200">Model Configuration</h3>
                <div className="space-y-2 text-sm text-slate-400">
                  <div>
                    Algorithm: <span className="text-slate-200 font-semibold">Random Forest Classifier</span>
                  </div>
                  <div>
                    Train/Test Split: <span className="text-slate-200 font-semibold">80/20</span>
                  </div>
                  <div>
                    Random State: <span className="text-slate-200 font-semibold">42</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
