export async function POST(request: Request) {
  try {
    const data = await request.json()

    // For demo purposes, we use simple heuristics
    const riskScore =
      Math.abs(data.v1) * 0.2 +
      Math.abs(data.v2) * 0.15 +
      Math.abs(data.v3) * 0.1 +
      (data.amount > 1000 ? 0.15 : 0) +
      Math.abs(data.v4) * 0.12

    const prediction = riskScore > 1.5 ? 1 : 0
    const probability = Math.min(riskScore / 3, 1)
    const risk_level = probability < 0.3 ? "low" : probability < 0.7 ? "medium" : "high"

    return Response.json({
      prediction,
      probability,
      risk_level,
    })
  } catch (error) {
    return Response.json({ error: "Prediction failed" }, { status: 500 })
  }
}
