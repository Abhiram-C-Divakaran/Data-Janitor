"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, CheckCircle, Loader } from "lucide-react"

interface PredictionResult {
  prediction: number
  probability: number
  risk_level: "low" | "medium" | "high"
}

export function FraudDetectorForm() {
  const [formData, setFormData] = useState({
    time: "",
    amount: "",
    v1: "",
    v2: "",
    v3: "",
    v4: "",
    v5: "",
    v6: "",
    v7: "",
    v8: "",
    v9: "",
    v10: "",
  })

  const [result, setResult] = useState<PredictionResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch("/api/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          time: Number.parseFloat(formData.time),
          amount: Number.parseFloat(formData.amount),
          v1: Number.parseFloat(formData.v1),
          v2: Number.parseFloat(formData.v2),
          v3: Number.parseFloat(formData.v3),
          v4: Number.parseFloat(formData.v4),
          v5: Number.parseFloat(formData.v5),
          v6: Number.parseFloat(formData.v6),
          v7: Number.parseFloat(formData.v7),
          v8: Number.parseFloat(formData.v8),
          v9: Number.parseFloat(formData.v9),
          v10: Number.parseFloat(formData.v10),
        }),
      })

      if (!response.ok) throw new Error("Prediction failed")
      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-blue-500" />
            Real-Time Fraud Detection
          </CardTitle>
          <CardDescription>Enter transaction details to check if it's fraudulent</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Primary Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Time (seconds)</label>
                <input
                  type="number"
                  name="time"
                  value={formData.time}
                  onChange={handleInputChange}
                  placeholder="0"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-md text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Amount ($)</label>
                <input
                  type="number"
                  name="amount"
                  value={formData.amount}
                  onChange={handleInputChange}
                  placeholder="0.00"
                  step="0.01"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-md text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>

            {/* PCA Components */}
            <div>
              <h3 className="text-sm font-semibold text-slate-300 mb-3">PCA Components (V1-V10)</h3>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                {["v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10"].map((field) => (
                  <div key={field}>
                    <label className="block text-xs font-medium text-slate-400 mb-1 uppercase">{field}</label>
                    <input
                      type="number"
                      name={field}
                      value={formData[field as keyof typeof formData]}
                      onChange={handleInputChange}
                      placeholder="0"
                      step="0.01"
                      className="w-full px-2 py-1 bg-slate-900 border border-slate-600 rounded-md text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-md transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading && <Loader className="w-4 h-4 animate-spin" />}
              {loading ? "Analyzing Transaction..." : "Check for Fraud"}
            </Button>

            {/* Error Message */}
            {error && (
              <div className="p-3 bg-red-900/20 border border-red-700 rounded-md text-red-400 text-sm">
                Error: {error}
              </div>
            )}
          </form>
        </CardContent>
      </Card>

      {/* Prediction Result */}
      {result && (
        <Card
          className={`border-2 ${
            result.prediction === 0 ? "bg-green-900/20 border-green-700" : "bg-red-900/20 border-red-700"
          }`}
        >
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              {result.prediction === 0 ? (
                <CheckCircle className="w-12 h-12 text-green-500 flex-shrink-0" />
              ) : (
                <AlertTriangle className="w-12 h-12 text-red-500 flex-shrink-0" />
              )}
              <div className="flex-1">
                <h3 className="text-lg font-bold mb-2">
                  {result.prediction === 0 ? "✓ Legitimate Transaction" : "⚠ Fraudulent Transaction Detected"}
                </h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Prediction:</span>
                    <span
                      className={
                        result.prediction === 0 ? "text-green-400 font-semibold" : "text-red-400 font-semibold"
                      }
                    >
                      {result.prediction === 0 ? "Valid" : "Fraud"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Confidence:</span>
                    <span className="text-slate-200 font-semibold">{(result.probability * 100).toFixed(2)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Risk Level:</span>
                    <span
                      className={`font-semibold ${
                        result.risk_level === "low"
                          ? "text-green-400"
                          : result.risk_level === "medium"
                            ? "text-yellow-400"
                            : "text-red-400"
                      }`}
                    >
                      {result.risk_level.charAt(0).toUpperCase() + result.risk_level.slice(1)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
