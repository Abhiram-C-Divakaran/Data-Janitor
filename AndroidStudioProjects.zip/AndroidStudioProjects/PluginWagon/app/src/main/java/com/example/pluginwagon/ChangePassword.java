package com.example.pluginwagon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ChangePassword extends AppCompatActivity {
    EditText curpass,Newpass,confpass;
    Button change;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        curpass = findViewById(R.id.editTextTextPersonName12);
        Newpass =findViewById(R.id.editTextTextPersonName14);
        confpass =findViewById(R.id.editTextTextPersonName15);
        change =findViewById(R.id.button5);

    }
}