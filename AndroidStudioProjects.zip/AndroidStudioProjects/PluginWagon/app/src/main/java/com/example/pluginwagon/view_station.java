package com.example.pluginwagon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class view_station extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_station);
    }
}